# Verification record — 2026-11-05

## Automated checks

`node --test tests/*.test.mjs`: 17 passing tests covering:
- API identity, per-user isolation, optimistic version conflict, foreign-origin rejection and role denial.
- Duplicate registration and bed occupancy; failed actions preserve state.
- Scheduling, rescheduling and check-in create distinct encounters.
- Collection → receipt → processing → final result; corrections retain previous values.
- Resident cosign requirements, signed-note immutability, addenda and discharge gates.
- Medication order versus administration; wrong-patient rejection.
- Interface mapping failure, unavailable destination, replay deduplication and delayed reporting refresh.
- All 20 support cases through evidence, action, verification and structured resolution.
- Configuration testing/approval/release, department-scoped required fields and rollback.
- API simulation 401/403/404/200; snapshot recovery.
- All 15 SQL solutions against current, empty and two varied datasets; read-only enforcement and incorrect-query rejection.

TypeScript checking passed. Production build passed before final packaging; final package build repeats against the committed inputs.

## Browser limitation

Managed preview reported a URL but both the browser and direct connection were refused. No preview visual or click-path verification is claimed. Production deployment and any subsequent published-site checks are recorded in the delivery response.

## Deliberate simulation boundaries

The historical screenshot interface is preserved with a shared training-record panel. Original authored chart edits now use the shared API, with patient/encounter association checks and signed-note protection. Historical sample documents remain reference fixtures. Clinical, Support and Analytics training workflows share D1-backed state. SQL scoring is inspectable browser-side self-practice. Infrastructure probes and FHIR-shaped responses are simulated. Reporting jobs process in the server background after successful saves, with optimistic concurrency retries and exactly-once state commits. Automatic reporting is configurable. Written investigation evidence receives rule-based feedback. Strong, weak and unsafe responses are covered by tests. These boundaries are labelled in the app.

New tests cover shared chart edits, cross-patient rejection, writing assessment quality, and background completion with a concurrent-write retry. Production visual verification still requires a signed-in browser.
