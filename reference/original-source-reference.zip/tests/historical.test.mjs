import test from 'node:test';
import assert from 'node:assert/strict';
import {seed,apply} from '../lib/training/domain.mjs';
test('historical chart imports are idempotent and preserve signed documents',()=>{
 let s=apply(seed(),'chart',{patient:'9301254',command:'initialize'});
 const count=s.notes.length,results=s.results.length;
 assert.equal(count,16);assert.ok(results>100);
 s=apply(s,'chart',{patient:'9301254',command:'initialize'});
 assert.equal(s.notes.length,count);assert.equal(s.results.length,results);
 const note=s.notes[0];
 assert.throws(()=>apply(s,'editNote',{id:note.id,body:'Overwrite'}),/immutable/);
 s=apply(s,'chart',{patient:'9301254',command:'addendum',id:note.id,body:'Scenario correction with retained original'});
 assert.equal(s.notes[0].body,note.body);assert.equal(s.notes[0].addenda.length,1);
});
test('historical result corrections preserve values and reject wrong patients',()=>{
 let s=apply(seed(),'chart',{patient:'9301254',command:'initialize'});
 const r=s.results[0];s=apply(s,'role',{role:'Nurse'});
 assert.throws(()=>apply(s,'chart',{patient:'16442684',command:'correctResult',id:r.id,value:'141',reason:'Wrong identity'}),/association/);
 s=apply(s,'chart',{patient:'9301254',command:'correctResult',id:r.id,value:'141',reason:'Corrected synthetic source value'});
 assert.equal(s.results[0].history[0].value,r.value);assert.equal(s.results[0].revision,2);
 s=apply(s,'chart',{patient:'9301254',command:'notesRead'});
 assert.ok(s.notes.every(n=>n.reviewedAt));assert.equal(s.results[0].reviewed,false);
});

test('historical category dates and missing values retain reference semantics',()=>{
 const s=apply(seed(),'chart',{patient:'9301254',command:'initialize'});
 assert.ok(s.results.some(r=>r.category==='HEMATOLOGY'&&r.created.startsWith('2013-08-28')));
 assert.ok(s.results.some(r=>r.name==='POC INR'&&r.created.startsWith('2017-02-02')));
 assert.ok(!s.results.some(r=>r.value===''));
});
