# Hyperspace Practice — healthcare IT training

Independent educational simulator built on the original screenshot recreation. Fictional records only; no Epic connection or certification claim.

## Environments

- **Clinical:** screenshot reference chart plus connected records, registration/search, scheduling/rescheduling/check-in, multiple encounters, admission/transfer/discharge, order signatures, specimen collection/receipt/processing, results and corrections, review, reconciliation, MAR given/held/refused, notes/pend/sign/cosign/addendum, private sticky notes, observations and simulated communications.
- **IT Support:** 20 evidence-driven cases, scoped role actions, users/approved-access execution, sessions, health/diagnostics, interface mappings/replay/quarantine/acknowledgment, FHIR-shaped API failure lab, change request/testing/UAT/release/rollback, knowledge base, audit and structured resolutions.
- **Analytics:** real read-only SQLite in a worker, fixed schema including empty tables, 15 exercises checked against four datasets, query history/saving/CSV, reporting/census/cohorts, explicit extraction and failure injection, staging/reporting/warehouse/cache comparisons.
- **Training:** seven-day path, connected capstone, case rubric, reflections, portfolio artifacts, JSON/Markdown exports and five resettable snapshots.

## Local development

Requires Node 22.13+ and pnpm. `pnpm install`, `pnpm build`. Apply the schema locally using the starter Wrangler command:

```
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_busy_silverclaw.sql
```

Run `pnpm dev`. The managed Sites environment uses its preview launcher instead. `node --test tests/*.test.mjs` runs workflow and real SQLite worker tests. `pnpm exec tsc --noEmit` checks TypeScript.

## Storage and authorization

D1 stores one versioned JSON workspace per platform-authenticated user. Every mutation is server-authorized by practice role. Role switching is deliberately allowed for educational handoffs, not an enterprise privilege system. Optimistic version checks prevent concurrent lost writes. Transactions act on a clone; invalid operations cannot partially mutate persisted state. Signed notes retain addenda; corrected results retain history. State is separate from the historical reference chart's local fixture.

The screenshot reference is `/clinical/index.html`. Its connected-record panel and authored chart edits use the persistent API. Original notes, drafts, orders, intake/output, handoffs, list membership, result review, sticky notes and care-team actions share the training workspace. Historical sample documents and laboratory grids remain reference fixtures; new records appear in the connected panel and training workflows.

## Accuracy and limits

1. Screenshot recreation: original clinician interface and historical fixture.
2. Workflow simulation: clinical lifecycle concepts.
3. Educational approximation: support/admin tools, FHIR-shaped responses and synthetic relational schema.

These are not proprietary Epic build tools. No external communications, prescription orders, real clinical integrations, or machine commands are executed. Infrastructure and healthcare decisions are scenario-driven. Queued reporting jobs process automatically in the Worker request background using waitUntil. Automatic reporting can queue loads after workflow mutations. This is event-driven background processing rather than a timed recurring scheduler. SQL assessment runs in the browser, with varied fixtures, and is not a tamper-proof exam. Written explanations receive deterministic feedback for evidence relevance, authorization, validation, communication, and follow-up. The rubric remains an educational heuristic rather than a substitute for human assessment. Report definitions identify populations, grain, timing, exclusions and nulls; most reports cover the full snapshot, while dates/departments apply to encounter/appointment reports as labelled.

## Recovery

Milestone ZIPs contain source, the expansion specification, migrations, vendored SQLite, tests, and lockfile. Dependencies/build/runtime data and Git credentials are excluded. The canonical source is also pushed to the existing Site repository at deployment. No private data is needed to initialize the synthetic hospital.
