# Epic Hyperspace Simulator — Visual and Interaction Specification

Prepared for Mahmud · 4 November 2026 · Reference set: 19 supplied screenshots

**This is a specification only. No website or application code has been created.** The target is the particular desktop Hyperspace practice environment shown in the references, including its dense layout, older Windows styling, patient-list workflow, persistent sticky note, Results Review, and split-pane note writing.

## 1. How to read this specification

The screenshots are the authority for appearance and the demonstrated sequence. Public hospital training references support the general purpose of Epic features; they do not prove the exact configuration of the system in this video.

- **Observed:** directly legible or visibly demonstrated in the supplied images.
- **Verified:** the general function is supported by a public institutional source listed at the end.
- **Inferred:** a likely interaction or meaning, not demonstrated by the still images.
- **Proposed simulator behavior:** a deliberate choice for the future build where the reference does not show the complete workflow.
- **Unresolved:** cropped, illegible, icon-only, local, or otherwise not reliably identifiable.

All coordinates below are approximate image pixels from the upper-left corner, using a nominal **1920 × 1080** canvas. They are implementation targets, not a claim of pixel-exact measurement. Images actually range from 1898–1919 pixels wide and 1057–1079 pixels high. Images 1–2 omit the roughly 22-pixel native window title bar visible in later images. Normalize that difference before comparing alignment.

Some names, ages, dates, and clinical details contradict each other. Preserve these as separate reference fixtures when matching screenshots; do not treat the sequence as a coherent real clinical case or silently substitute corrected values. Clinical text here is a transcription target, not treatment guidance.

Hyperspace is the integrated workspace hosting Epic applications [S1]. These pictures show a clinician-facing inpatient workflow within it. This specification reproduces that workflow; it does not establish what an Epic analyst's configuration tools look like.

## 2. Screenshot index and demonstrated sequence

| Image | Filename suffix | Visible state | Transition and fidelity notes |
|---|---|---|---|
| 1 | 202334 | Patient Lists, seven patients | Conan's Custom List; Himsepsis, Harden selected; lower 24 hour snapshot report visible. |
| 2 | 202338 | Patient Lookup dialog, empty search | User confirms this follows Add Patient. Name/MRN has focus. Two already-open patients appear at bottom. |
| 3 | 202342 | Patient Lookup, MRN entered | Name/MRN contains 9301254; hourglass cursor; several buttons pale/disabled. |
| 4 | 202346 | Same search state | Appears to duplicate image 3; no distinct new interaction is established. |
| 5 | 202351 | Patient Lists, eight patients | Xxteshim, Aneone is added at top of grid and bottom of the expanded personal-list tree. Himsepsis remains selected. |
| 6 | 202358 | Xxteshim row highlighted; handoff hover | White callout displays the unresolved Illness Severity template text. Lower report still displays Himsepsis in this captured moment. |
| 7 | 202404 | Xxteshim chart, Summary activity | Patient storyboard at left; Rounding Report center; blank My Note editor at right. Exact chart-opening gesture is not shown. |
| 8 | 202413 | Empty sticky note opened | Trigger is the paper-note icon at upper left; floating yellow note appears near upper right, not beside the trigger. |
| 9 | 202417 | Sticky note populated | Five short lines entered; Summary and blank My Note remain behind it. |
| 10 | 202421 | Results activity | User confirms click on Results. All visible result categories selected; main table and timeline replace Summary. Sticky note and right editor persist. |
| 11 | 202426 | Chemistry filter | Only Chemistry highlighted/checked; chemistry rows and longer date range visible. |
| 12 | 202429 | Hematology filter | CBC, automatic differential, manual differential; dates extend to 2013. |
| 13 | 202433 | Micro & Infe… filter | Result area blank under retained date headings; do not invent microbiology results. |
| 14 | 202438 | Point of Care filter | POC and spirometry entries; tooltip explains click/Ctrl+click; all-available-results end panel. |
| 15 | 202443 | Notes activity and Transfer Orders sidebar | 16 notes; Hensley note selected; central document reader; narrow right sidebar shows No Orders. |
| 16 | 202447 | Notes plus new blank My Note | Right editor widens; date/time/service/type fields expanded. Note Type field focused. |
| 17 | 202452 | H&P type and cosigner lookup | Type H&P; Cosigner query mithu; Recent dropdown shows MOLLA, MITHU [510152481]. |
| 18 | 202457 | Same cosigner lookup | Appears to duplicate image 17; no distinct additional action established. |
| 19 | 202501 | Populated note template | Editor scrolled to Assessment & Plan / lower template; pink placeholders and a choice list visible; no final signing shown. |

There are gaps between captured states: the exact acceptance click after search, chart-opening gesture, new-note gesture, final cosigner selection, and template-insertion action are not shown. The future simulator should support plausible routes without representing them as observed actions.

## 3. Visual system

### 3.1 Overall character

This is a tightly packed desktop clinical application, not a spacious modern dashboard. Use very small gaps, compact controls, rectangular panels, thin dividers, many text links, numerous tiny icons, and multiple independent scrollbars. Most workspace surfaces are cool gray; reports and documents are white; the application shell and patient storyboard are charcoal. Cyan indicates selection and active pane boundaries. A red patterned global toolbar anchors the top.

Avoid large rounded cards, generous padding, oversized headings, drop-shadow-heavy panels, giant pill navigation, or mobile-first stacking at the reference desktop size. Preserve intentional blank gray spaces in Summary and blank white spaces in Results Review.

### 3.2 Colors

The first four values were identified from frequently occurring screenshot pixels. Other values are visual estimates to tune during a future screenshot overlay comparison. Compression, antialiasing, and recorded video affect exact colors.

| Surface or state | Target color | Confidence / usage |
|---|---|---|
| Main workspace gray | #D3D5DB | Measured dominant screenshot color. Toolbars, panel background, gutters. |
| Report/document background | #FFFFFF | Measured. |
| Selected patient row | #9CE4EC | Measured dominant selection in image 1. |
| Sticky-note body | #FEFE95 | Measured dominant yellow in images 8/10. |
| Storyboard charcoal | approximately #282827 | Measured frequent dark tone in chart views. |
| Upper tab strip | approximately #202223 | Near-black with subtle dark pattern. |
| Global menu red | approximately #A80B11 to #D31A22 | Dark/light diagonal stripes, not one flat fill. |
| Native title bar / dialog cyan | approximately #60C7E1 | Narrow blue top strip; Patient Lookup frame. |
| Strong teal border/handle | approximately #1598AF | Selected controls, split-pane grab handle. |
| Results cell pale cyan | approximately #E4F5F7 | Narrow filled cells with a darker teal left rule. |
| Regular text | approximately #333333 | Small, dense, sans serif. |
| Secondary text | approximately #777A7E | Field labels and metadata. |
| Hyperlinks | approximately #626CB0 | Muted periwinkle-blue report links. |
| Grid borders | approximately #C6C6C6 | Thin gray horizontal and vertical rules. |
| Warning bars | approximately #FFDC36 | COVID risk, allergy count, vaccine prompt. |
| Abnormal result text | approximately #C72C40 | Red numbers and exclamation indicators. |
| Summary teal accent | approximately #4AAFA8 | Patient Summary and weight cards. |
| Summary blue accent | approximately #389ED8 | Vitals card. |
| Summary lime accent | approximately #A6C53D | Order cards and LDA. |
| Summary purple accent | approximately #9484DE | Disease reports, radiology, unresolved labs. |
| Summary magenta accent | approximately #CB4A99 | Current IP Meds. |
| Note placeholder | approximately #FFE0ED with #C88EA8 outline | Pink *** fields and POA selector. |

### 3.3 Typography and controls

The exact font cannot be proven from raster screenshots. Start with a compact Windows sans-serif family such as Segoe UI, with Arial/Tahoma fallbacks; tune against the images before committing.

| Element | Approximate size at nominal resolution | Treatment |
|---|---|---|
| Native title and top menu | 12–14 px | Normal weight; menu white on red. |
| Main activity heading | 19–21 px | Bold charcoal. |
| Activity tabs | 14–16 px | White/gray on dark inactive tabs; dark on light active tab. |
| Standard controls and list text | 12–14 px | Compact line height. |
| Storyboard details | 11–13 px | Light gray on charcoal. |
| Result table | 11–12 px | Row height roughly 20 px. |
| Note reader body | 15–17 px | Many bold paragraphs/headings. |
| Sticky note | 11–12 px | Compact, nearly single-spaced. |
| 24-hour report patient heading | 23–25 px | Bold, one long line. |

Buttons have thin gray borders and a subtle white/gray bevel or gradient. Inputs are white, rectangular, roughly 22–26 px tall. Focused inputs have a blue outline. Disabled controls are low-contrast gray. Small lookup fields end in a magnifying glass; date inputs use a calendar symbol. Tabs have thin colored strips across their upper edges and circular colored pictograms. Selected rows use cyan, not only bold text.

## 4. Persistent application shell

### 4.1 Horizontal layers

| Region | Approximate box (x, y, width, height) | Contents |
|---|---|---|
| Native window title | 0, 0, 1920, 22 | Epic E at left; centered title; mail/count and window controls at far right. |
| Red global toolbar | 0, 22, 1920, 27 | Epic menu and application-wide shortcuts. |
| Workspace tabs | 0, 49, 1920, 28 | Small icon shortcuts; open patient and SmartTools tabs; practice/user badge at right. |
| Chart activity tabs | 167, 78, remaining width, 50 | Present after chart opens; absent on Patient Lists. |
| Main body | Starts around y=128 in chart | Storyboard, current activity, optional sidebar. |

Native title text: **Hyperspace - Practice - IP INTERNAL MEDICINE/HOSPITALISTS SERVICE - CONAN LIU**. The earliest two images crop out this title bar.

### 4.2 Red toolbar, left-to-right inventory

Positions are approximate button starts. These controls are visible but none of their destination screens are shown in the reference set.

| Label | Approximate x | Function / confidence |
|---|---:|---|
| Epic ▼ | 3 | Main application menu. General function verified [S1]; submenu contents unresolved. |
| Patient Station | 80 | Locate a patient and access patient/encounter information [S1]. |
| Encounter | 193 | Encounter-related access; exact local launcher unverified. |
| Telephone Call | 280 | Likely telephone-encounter documentation; destination unshown. |
| Chart | 390 | Open chart access [S1]. |
| Care Plans Guide | 447 | Local guide shortcut; destination unverified. |
| CRC | 573 | Local abbreviation; do not invent an expansion. |
| CURES 2.0 | 628 | Labeled external/local resource shortcut; exact integration unverified in this research. |
| UpToDate | 721 | Labeled clinical-reference shortcut; destination unshown. |
| ED Manager | 801 | ED workflow launcher inferred from label; screen unshown. |
| Clinical Calculator | 903 | Calculator resource inferred from label; calculators unshown. |
| Remind Me | 1029 | Reminder function inferred; editor and reminder rules unshown. |
| Know (Epic Help) | 1117 | Help shortcut, readable label. |
| IM MMQS | 1245 | Best-effort reading of local shortcut; exact spelling/expansion unresolved. |
| Dragon Login | 1326 | Speech/dictation login inferred from label. |
| Personalize ▼ | 1424 | Personalization entry; general customization supported [S1]. |
| » and small utility icons | 1606–1693 | Overflow and unlabeled utilities; exact identities unresolved. |
| Print ▼ | 1700 | Printing entry [S1]. |
| Secure | 1762 | Lock/security-session action inferred; do not equate automatically with Log Out. |
| Log Out | 1839 | End session, inferred from label. |

Far-right lower strip: red **PRACTICE** badge, **CONAN LIU**, **EpicCare**, search/magnifier. Keep PRACTICE visible in every state. The black workspace row contains **Xxteshim, Aneone**, **SmartTools**, and **Himsepsis, Harden**. The active patient's tab gains a cyan upper edge and close ×. The small left-hand shortcut icons look like clipboard, list, chart, speech bubble, and grid/calendar symbols; their tooltips are not shown, so their exact actions remain unresolved.

## 5. Patient Lists: images 1–6

### 5.1 Layout

On title-bar-inclusive images: heading at x≈5,y≈83; toolbar at y≈123; left tree from x=0–225; main list from x≈228–1903. List header around y=149–180, column labels y≈180–219, rows y≈220–603. Lower report begins at y≈606, separated by a horizontal draggable divider with a tiny central handle.

In images 1–2, subtract about 22 px from these y positions. The lower report is already open, not a separate modal.

### 5.2 Action toolbar

All buttons occupy one compact horizontal row. A small icon usually precedes its text. Ordering is important.

| Control | Approximate x | Purpose and future interaction |
|---|---:|---|
| Edit List ▼ | 12 | Configure/manage personal lists. Exact dropdown unshown; use source-backed basic list concepts [S2]. |
| Remove Patient | 106 | Proposed: remove selected patient from current personal list, not delete their chart. |
| Add Patient | 224 | Observed: opens Patient Lookup. Adds an existing patient to this list; this is not a patient-registration form. |
| Wrap Text | 325 | Wrap long grid text; disabled in reference. |
| Copy | 420 | Copy selected data; visible enabled appearance. Exact copy payload unshown. |
| Paste | 479 | Disabled in reference. |
| Open Chart | 542 | Open selected patient chart; general function [S1]. |
| Sign Out Rpt | 647 | Handoff/sign-out report, inferred from label. |
| Write Handoff | 746 | Handoff editing, inferred. |
| Print Handoff | 850 | Handoff print action, inferred. |
| Reports ▼ | 950 | Patient-report chooser [S3]. |
| Labs Pt List | 1039 | List-oriented lab report, exact report unshown. |
| Order Inquiry | 1142 | Order lookup/review, inferred; exact screen unshown. |
| Collect | 1248 | Collection workflow inferred; disabled-looking. |
| Sign In | 1310 | Likely care-team/list sign-in; not application login. Local behavior unverified. |
| Sign Out | 1382 | Likely care-team/list sign-out; not application logout. Local behavior unverified. |
| Patient Transport | 1455 | Patient transport entry; detailed local workflow unshown. |
| Data Validate | 1581 | Local validation action; target and rules unverified. |
| First Contact | 1681 | Likely first-contact assignment; unverified. |
| More ▼ | 1778 | Additional toolbar actions; menu unshown. |

### 5.3 Left tree

Width approximately 225 px. Small triangles expand/collapse folders. Folder icons are blue; personal-list icons resemble yellow paper/pencil; patient items use tiny dark person glyphs. The selected personal list is cyan.

**My Lists**, top to bottom:

1. Expanded **\*Conan's Custom …**.
2. Its patient children: **Baklava, Andrew**; **Bamboo, Andrew**; **Bananasfoster, An…**; **Douglasfir, Andrew**; **Dracula, Andrew**; **Elm, Andrew**; **Himsepsis, Harden**. After addition: **Xxteshim, Aneone** at the bottom of this tree group.
3. **CCU Discharges**.
4. **Clinic Patients**.
5. **ED Admits**.
6. **Heme Onc Discha…**.
7. **Interesting Cases**.
8. **MICU Discharges**.
9. **My Patients**.
10. **Wards Discharges**.
11. Expanded **Shared Patient Lists**, including **Cardiology Consul…**, **CCU Platinum** with a visible 0, and more clipped entries.

A divider separates **Available Lists**, containing **Recent Searches**, **System Lists**, **Hosp Service Dept**, **Inpatient Phlebotom…**, **OB Patients & Pendi…**, **PhysicianConnect**, **Pre-Admit Patients**, and partially visible **Recent Discharges**. Do not expand clipped names without additional evidence.

The tree has its own scrollbar. Its scroll position and the main grid's scroll position are independent.

### 5.4 Main grid and data

Header: **Conan's Custom List 7 Patients**, then **8 Patients** after adding. Right side: **Refreshed just now**, green refresh icon, and **Search Current Locat…** field with a dropdown arrow.

| Column | Approximate left x | Width | Visible content / interpretation |
|---|---:|---:|---|
| Bed ▲ | 229 | 84 | Bed identifier or wrapped location; ascending sort marker visible. |
| Patient Name | 313 | 108 | Last, First, often two lines. |
| MRN | 421 | 83 | Medical record number. |
| Handoff - Summary | 504 | 410 | Template-like text displayed literally. |
| Temp | 914 | 58 | 36.5 with (97.7) below. |
| BP | 972 | 66 | 110/78. |
| Pulse | 1038 | 49 | 88. |
| Resp | 1087 | 57 | 18. |
| Temp | 1144 | 48 | 98. Header visibly repeats Temp; do not relabel as oxygen saturation without evidence. |
| Handoff - Primary To Do | 1192 | 352 | Mostly em dash/empty. |
| New Rslt Flag | 1544 | 93 | Small red exclamation-style indicator. |
| New Notes | 1637 | 52 | Tiny yellow/green paper-plus icon. |
| RQD MD Doc | 1689 | 74 | Red circular status icon or dash. Meaning likely required physician documentation, exact legend unshown. |
| Foley RQD Doc | 1763 | 85 | Red circular status icon; exact legend unshown. |
| Code Status | 1848 | 39 | Small hollow reddish circle. Do not infer its code mapping. |

Rows have thin gray separators. Standard rows are roughly 53 px tall. The expanded selected row is about 85 px because it includes shortcut buttons. Top selected row fills cyan across all columns and has a darker cyan outline.

| Patient | MRN | Bed/location shown |
|---|---|---|
| Himsepsis, Harden | 16442684 | 814101 |
| Baklava, Andrew | 16440285 | P3 / NEUROS… / ICU… |
| Douglasfir, Andrew | 16440288 | P3 / NEUROS… / ICU… |
| Dracula, Andrew | 16440292 | P3 / NEUROS… / ICU… |
| Bamboo, Andrew | 16440295 | P3 / NEUROS… / ICU… |
| Elm, Andrew | 16440297 | P3 / NEUROS… / ICU… |
| Bananasfoster, Andrew | 16440300 | Lower partially clipped row |
| Xxteshim, Aneone | 9301254 | 332302; appears first after addition |

Handoff cells show a literal token resembling **{Illness Severity:18418}**, possibly with doubled braces; brace count is not sharp enough to guarantee. Preserve a screenshot-matched literal token instead of converting it into a clinical severity label.

Selected-row shortcuts, left-to-right: **Orders**, **Notes**, **Chart Review**, **Results Review**, **Summary**. They have individual rectangular buttons and small icons except Notes/Summary, which appear mostly text.

Image 6: Xxteshim highlighted; hover callout near x≈917,y≈220,w≈596,h≈43. White fill, gray outline, left-pointing notch, same Illness Severity token. This is a tooltip-like callout, not another row or a clinical note editor.

### 5.5 Lower patient report

Context strip: **Himsepsis, Harden**; **Unit: E8MS**; **Room: 8141**; **Bed: 814101**. Below: small navigation arrow, refresh, binoculars, then report shortcuts:

**24 hour snapshot**, **Rounding Report**, **VS**, **Vent**, **InfCtrl**, **MAR**, **I/O**, **Micro**, **Orders**, **Meds**, **Team**, **LDA**, **ED**, **OP Info**.

At far right: report search/selection field reading **24 hour snapshot**, a wrench, a tiny menu arrow, and zoom-style icons. Report toolbar customization and report defaults are documented generally [S3]; exact local report definitions are not public here.

Report heading: **Himsepsis, Harden MRN: 16442684 (CSN: 80145416) (66yr M) (Adm: 09/16/22 1415)**. MRN identifies the patient record; CSN identifies the encounter/contact context. Body uses tiny text in several widely spaced columns:

- Attending Provider: **Wisner, David, MD / Chang, Gregory Youngnam, MD**.
- Another provider line: **Sinigayan, Voltaire R, MD** (best-effort spelling).
- Allergies in red: **Doxycycline, Penicillin**.
- Last verified: **09/16/22**.
- Infection: **(unk)**.
- Code Status: **FULL**; link **Advance Care Planning Activity**.
- Height: **1.753 m (5' 9")**; weight **133 kg (293 lb 3.4 oz)**.
- Right-side anticipated-diagnosis text: **Periumbilical abdominal pain [R10.33]**, **Umbilical hernia with obstruction, without gangrene [K42.0]**. Label appears abbreviated as Anticipated Dx.
- Tiny upper-right report location: **E8MS-814101**.

**Current IP Meds**, subtitle **(From admission, onward)**, Expand link on the right. Table columns: Start; medication name; Stop; Status; Route; Frequency; Ordered. Visible medication links include:

| Visible medication text | Visible route/frequency example |
|---|---|
| NaCl 0.9% Infusion [281231568] | IV; CONTINUOUS INFUSION |
| Enoxaparin (LOVENOX) Injection 40 mg [281231501] | SC; DAILY AT 2100 |
| Docusate (COLACE) Capsule 100 mg [281231494] | PO; TWO TIMES DAILY |
| Multivitamins (INFUVITE) 10 mL, Thiamine 100 mg, Folic Acid 1 mg in D5W 500 mL Infusion [281231743] | IV; DAILY AT 2200 |
| Fentanyl patch REMOVAL 1 patch [281231744] | TD; EVERY 72 HOURS NOW |
| Fentanyl (DURAGESIC) 100 mcg/hr Patch 1 patch [281231745] | TD; EVERY 72 HOURS NOW |
| Oxycodone (ROXICODONE) Tablet 5-10 mg [281231746] | PO; EVERY 4 HOURS NOW |
| Ibuprofen (MOTRIN) Tablet 600 mg [281231739] | PO; EVERY 4 HOURS IF NEEDED |
| NaCl 0.9% Infusion [281231726] | IV; CONTINUOUS INFUSION |

Visible dates mix September 2022 and January 2018. Preserve that mismatch in a reference fixture. Tiny order IDs are best-effort transcriptions, not reliable identifiers for any external system.

## 6. Patient Lookup: images 2–4

Centered Windows-style dialog, approximately x=508,y=314,w=903,h=451 in title-bar-inclusive images. Cyan outer border/frame, cyan title strip, centered **Patient Lookup**, red-orange close × at upper right. Underlying patient list remains fully visible with no dark modal scrim.

Tabs: **Patient Search** active white tab; **Recent Patients** gray inactive tab.

| Left column label | Input position/appearance | Right column label | Input appearance |
|---|---|---|---|
| Name/MRN: | x≈657,y≈389,w≈238; blue focus border | EPI ID: | Gray disabled field, x≈1026,w≈142 |
| Birthdate | Small date field with calendar | PCP/Care Team | Long lookup field with magnifier |
| Sex | Small lookup field | Street Address | Long plain input |
| City | Long plain input | State | Long lookup field |
| Zip | Long field with small trailing control | SSN | Short field, small trailing control |
| Service Area: | Long lookup field | — | — |

Below fields: unchecked **Use sounds-like** and **My patients**. Bottom of form: **Find Patient**, **Clear** on left; **Accept**, **Cancel** on right. In initial image Accept is disabled; while search is captured in progress, Find Patient/Clear/Accept/Cancel appear pale. Exact enabling rules beyond that are unshown.

Lower subpanel title: **Open Patients**. Columns: **Patient Name**, **MRN**, **ID Type**, **Sex**, **Birth Date**, **Address**, **SSN**.

| Patient name | MRN | ID type | Sex | Birth date | Address | SSN |
|---|---|---|---|---|---|---|
| XXTESHIM,ANEONE | 9301254 | MRN | M | 01/21/1955 | 4158 33rd st, Sacramento CA 95817 | xxx-xx-xxxx |
| HIMSEPSIS,HARDEN | 16442684 | MRN | M | 01/21/1956 | 4158 33rd st, Sacramento CA 95817 | xxx-xx-xxxx |

First row is strong Windows selection blue with white text, unlike the cyan patient grid selection. Open Patients is not proof that a new search has returned: those rows are already present before typing.

Proposed complete simulator flow: Add Patient → focus Name/MRN → enter 9301254 → Find Patient/Enter → show matching existing practice patient → select/Accept → close dialog → add exactly one membership to Conan's list → count becomes eight. Cancel/× closes without adding. Clear empties search fields. Re-adding the same MRN should not produce duplicates. A no-match query should return an empty search result, not create a real patient record. These completion rules fill gaps in the screenshots.

## 7. Open patient chart: persistent storyboard and tabs

### 7.1 Chart geometry

At 1920×1080, left storyboard width ≈167 px. Central workspace x≈168–1274, width ≈1106. Standard right editor starts x≈1280 and fills ≈640 px. The separator includes a tall teal collapse/expand handle centered vertically near y≈540–616. Most panes have their own scrollbars.

On image 15 the right Transfer Orders pane is narrower, beginning near x≈1530; the central reading area is wider. The activity tab labels expand accordingly. Do not force all screenshots to use identical central/sidebar widths.

### 7.2 Upper-left patient area

Above the demographics: pale yellow paper sticky-note icon near x≈13,y≈84; a second pale blue paper icon below it; a round patient image around x≈52,y≈83,w≈60,h≈60; clustered small circular status/action badges to its right; back arrow around x≈175,y≈93. The exact identities of the second paper icon and tiny circular badges cannot be read.

The sticky-note trigger is in this upper-left region. Its popup appears across the top-right of the central workspace. Keep trigger location and popup location distinct.

### 7.3 Storyboard content in order

Dark background, center-aligned identity near top, subsequent small blocks separated by fine rules. Some entries are clickable-looking colored text or yellow bands.

| Approximate y | Visible content |
|---:|---|
| 170 | **Aneone Xxteshim**, cyan-blue name |
| 193 | Male, 67yr, 1/21/1955 |
| 211 | MRN: 9301254 |
| 231 | Bed: P3NI-3P323-332302 (best-effort reading) |
| 251–278 | Service, Level of Care: (A) Gastroenterology, Med/Surg |
| 286–309 | Payor/Plan: BLUE CROSS/BLUE CROSS PBP |
| 319 | Code: FULL |
| 339 | ACP Docs: Yes - on file |
| 358–385 | White Search input |
| 391–413 | Yellow **COVID Complication Risk: 5** |
| 418 | COVID-19 Vaccine: Unknown |
| 437 | Pale status bar **COVID-19: Unknown** |
| 456–478 | Yellow **Order COVID Vaccine?** with alert icon |
| 492–538 | Provider portrait; **Johl, Hershan S, MD**; **Attending** |
| 548–570 | Yellow **Allergies (2)** |
| 578–603 | Suicide Precaution Orders: None |
| 618–644 | Blue **ADMITTED: 9/16/2021 (373 D)** |
| 652 | Patient Class: Inpatient |
| 673 | No expected discharge |
| 691–729 | Sepsis due to undetermined organism with acute respiratory failure (HCC) |
| 749 | Ht: 175.3 cm (5' 9") |
| 774 | Weight: 133 kg |
| 794 | Idl Wt: 70.7 kg |
| 819 | NO NEW RESULTS, LAST 36H |
| 848 | ACTIVE MEDS (4), purple |
| 872 | Scheduled (1) |
| 893 | Continuous (3) |

The presenter video covers the bottom-left after roughly y=901. Everything beneath that overlay is unobserved. Do not assume the storyboard ends there.

### 7.4 Chart activity tabs

From left to right: **Summary**, **Chart Review**, **Results**, **Notes**, **Orders**, **Intake/Output**, **Navigators**, **Teams**, **History**, **Flowsheets**. Later tabs can be clipped, obscured by the sticky note, or reduced to icons depending on sidebar width. In image 7, several labels truncate to **Sum…**, **Cha…**, **Inta…**, **Na…**.

| Activity | Accent/icon | Function and evidence |
|---|---|---|
| Summary | Teal, report-like icon | Aggregated patient reports; shown as Rounding Report here. |
| Chart Review | Blue, chart/folder-like icon | Historical encounter/document/lab/imaging/medication review [S4]. Destination not opened in this sequence. |
| Results | Pink/red flask in circle | Time-based diagnostic result review [S5]. |
| Notes | Magenta paper | Browse/create clinical notes [S7]. |
| Orders | Magenta clipboard | Review/place inpatient orders; medications, tests, procedures and related requests [S10]. |
| Intake/Output | Teal icon | Fluid intake/output review/documentation, inferred from label; screen unshown. |
| Navigators | Purple N | Workflow-organized documentation, inferred; exact navigator catalog unshown. |
| Teams | Pink people | Care-team management, inferred; unshown. |
| History | Gold clock | History review/documentation, inferred; unshown. |
| Flowsheets | Blue/white icon | Structured repeated observations, inferred; unshown. |

Right-side workspace tabs: **Sidebar Summary**, **Edit Note ▼**, **Transfer Orders**. These switch the secondary pane, not the whole patient chart. Blank right editor in Summary and Results proves the main activity and sidebar are independent.

## 8. Summary / Rounding Report: images 7–9

Heading **Summary** at x≈170,y≈132. Secondary report tabs at y≈160–190: **Rounding Report** active; **Overview**, **Order Hx**, **MAR**, **I/O**, **All**, **ICU**, **Endo**, **ID**, **Micro**, dropdown triangle. Small binoculars/print/zoom-like tools to the right; report search field **Rounding Report**; wrench/menu; refresh. Purple badge with a small pictogram and **3+**, help ?, and expand icon appear at upper right; exact badge meaning unresolved.

Central report uses irregular columns, not equal-height rows. White cards have narrow colored left edges and pale tinted title backgrounds. Coordinates below refer to image 7.

| Card | Approximate box | Text and controls |
|---|---|---|
| Patient Summary | 180,199,345,80 | Teal title; Show Details link; **61 year old with Left Chest Pain**. Age conflicts with storyboard and is preserved. |
| Vitals | 536,199,693,86 | Blue title; View Table; None. |
| Crossover To Do List | 180,286,345,49 | Teal title; Comment at right; otherwise blank. |
| I/O | 536,294,341,83 | Pale gold title; Timeline; View Table; None. |
| Current Oxygen Device/Flow | 886,294,352,94 | Gray title; Device (Oxygen Therapy): mechanical ventilator; Rate: 2 L/min. Preserve literal practice text. |
| Order History | 180,342,345,65 | Lime title; Jump to Order History Report link. |
| Place Orders | 180,415,345,64 | Lime title; Jump to Orders Sidebar link. |
| Weights (Last 2) | 886,395,352,130 | Teal title; 9/17/2021 1108 and 9/17/2021 2359; 132 kg (291 lb 0.1 oz), 133 kg (293 lb 3.4 oz). |
| 1st Recorded Weight | 886,532,352,99 | Teal title; Flowsheet Row / First Filed Value; first recorded weight 130 kg (286 lb 9.6 oz), filed 09/16/2021 1433. |
| Disease Specific Reports & References | 180,637,530,158 | Purple; three rows of compact rectangular report buttons. |
| Microbiology Results (last 21 days) | 718,637,521,64 | Gray title; No results found for the last 504 hours. |
| Radiology | 718,709,257,85 | Purple; (Last 24 hours); None. |
| Unresulted Laboratory Orders | 983,709,256,102 | Purple; (From admission through now); None. |
| Current IP Meds | 180,803,530,continues | Magenta; Continuous subheading; medication/dose/route/frequency/action table. |
| Lines, Drains, and Airways | 718,819,521,continues | Lime; Switch View; body silhouette; colored device markers and list. |

**Disease Specific Reports & References** buttons:

- Row 1: Home Meds; History; Problem List.
- Row 2: Cardiac Studies; PFT & Sleep Reports; Anticoagulation.
- Row 3: Glycemic Review; Results Review; Microbiology Hx; ABCDEF Bundle.

**Current IP Meds** visible continuous entries include NaCl 0.9% Infusion; Norepinephrine (LEVOPHED) 8,000 mcg in 250 mL infusion; Propofol (DIPRIVAN) 10 mg/mL continuous infusion. The presenter obscures the left edge of lower entries. Visible doses/rates include 100 mL/hr IV continuous; 7.4–123.8 mL/hr IV continuous; 4–39.6 mL/hr IV continuous. Last Action text includes New bag/syringe and Rate Change with historical dates. Do not extrapolate hidden entries.

**Lines, Drains, and Airways** legend: green Lines; pink Drains; purple Wounds. List entries: Peripheral IV over-the-needle cath… (374 days); Ureteral Catheter left ureter (374 days); Urethral Catheter indwelling cathet… (371 days); Incision Right abdomen (438 days). Small circular icons match the legend. Human silhouette near lower-left of card has a purple marker at right-abdominal area. Card continues below screenshot.

## 9. Sticky note: images 8–19

Popup position approximately x=1128,y=0,w=428,h=107; later image crops shift it a few pixels. Pale yellow body, thin gray/olive border, minimal shadow, compact title line. It overlaps the native title, red toolbar, workspace tabs, and chart activity tabs, so it must float above them rather than occupy layout space.

Header: **My Sticky Note  Last updated: Today**. Upper-right contains three small controls: diagonal/pop-out-looking arrow, chevron/collapse-looking glyph, and ×. Only × can be confidently mapped by its conventional appearance; the other exact operations need tooltip evidence.

Image 8 body placeholder: **Enter a private note for yourself**. Image 9 body, best-effort transcription preserving the informal style:

> 78 man heart failure diabetes afib  
> shortness of breath x 2 weeks  
> recently admitted for covid  
> has been off his eliquis due to some gi bleeding  
> swelling, lasix 40mg ED + ctx and azithromycin

The popup remains open across Summary → Results → Notes and while the sidebar changes. There is no visible save button. **Proposed simulator behavior:** save on typing/debounce or blur; store by practice user and patient; close hides without deleting; reopen restores; changing main activity preserves it. Cross-session persistence and actual Epic save timing are not proven by screenshots.

Institutional guidance distinguishes private and shared sticky-note configurations [S6]. This popup explicitly says private and My Sticky Note. Simulate that scope, not a shared formal note. The screenshot author's clinical shorthand does not establish that sticky notes replace formal clinical documentation.

## 10. Results Review: images 10–14

### 10.1 Layout and controls

Main activity heading **Results Review**, x≈170,y≈130. The patient storyboard and right blank My Note pane remain. Inside the central area:

- Result category tree x≈177–348, starting y≈161.
- Narrow gutter/splitter x≈348–365.
- Main result table x≈366–1258, y≈160–1002.
- Timeline controls at bottom y≈1004–1075.
- Vertical result scrollbar at the right edge of the table.
- Upper-right activity tools: purple badge **1**, help ?, expand arrow, ×. Meaning of purple badge unresolved.

The result grid is a matrix: test names down the left; dates/times across the top; values at intersections. Newest dates generally appear leftmost. Pale cyan cells with teal left borders repeat across columns. Blank intersections stay blank; they are not zero. Abnormal values are red with an adjacent red !. Do not equate every red indicator with a critical-result alert; its exact legend is unshown.

Verified general purpose: diagnostic results over time, expandable groupings, reference ranges, and graph/flowsheet views [S5]. The UI's settings, time-mark reset, and optional highlighting of new results are documented [S9].

Top tools: refresh and **Just now** or **<1m ago**; wrench; help/legend-like icons; **Time Mark** with clock/check-like icon; **All Rows** checkbox; circular double-chevron-style control near the date header. Exact purpose of unidentified icons is unresolved. Proposed All Rows behavior is to include otherwise hidden empty rows; validate against further evidence before treating as exact.

**Time Mark:** record the user's review cutoff and reset the new-result highlighting according to configured settings [S9]. It must not alter lab values or sign a clinical note. No click on Time Mark is demonstrated here.

### 10.2 Result tree, exact visible hierarchy

Search input at top, magnifier, and teal funnel button in filtered images. Category rows roughly 17–18 px tall. Triangles expand groups; right-hand column contains checkmarks on selected categories. Selected row has cyan fill and dark teal outline.

| Parent | Children, in displayed order |
|---|---|
| LABORATORY | BLOOD BANK; BLOOD GAS A…; CHEMISTRY; COAGULATION; HEMATOLOGY; MICRO & INFE…; POINT OF CA…; URINE |
| RADIOLOGY | CT; DIAGNOSTIC |
| CARDIOLOGY | EKG TRACING; ECHO |
| PULMONARY RE… | POC SPIROM… |

Some expanded names can be interpreted clinically, but keep clipped labels in the same widths. Image 14's tooltip confirms the full label **POINT OF CARE TESTING**. The full labels of BLOOD GAS A…, MICRO & INFE…, PULMONARY RE…, and POC SPIROM… are not directly shown.

Bottom of tree: **Collapse All**, a partially obscured neighboring button, a cyan filter chip such as CHEMISTRY/HEMATOLOGY, and **Reset t…** with curved arrow. Presenter video obscures part of this region.

Image 14 tooltip: **Click to show only POINT OF CARE TESTING**; **Ctrl + Click to remove POINT OF CARE TESTING**. Thus normal click isolates that category, while Ctrl+click participates in multiselection. Proposed consistent extension: Ctrl+click toggles other categories too; exact add behavior is not separately shown.

### 10.3 All-results state, image 10

Header includes green location bar **P3 Neurosurgical ICU** and purple **P3 PACU**. These are location/context bands over dates, not chart activity tabs.

Visible columns: 9/19/21 12:30; 9/19/21 10:00; 9/18/21 15:00; 9/18/21 11:00; 9/17/21 01:00; 9/16/21 01:00; 9/13/21 13:00; 9/13/21 01:00. Some date text is faint and compressed.

Visible groups: **TESTS - UCD**, Patient Blood Type; **VENOUS**, PO2, Ven; **CHEMISTRY PANELS**; **MISC. CHEMISTRY**; beginning of **ALL COAGULATION** / aPTT at bottom. PO2, Ven shows **58 !** and **40** in separate date columns.

Chemistry rows include Sodium, Potassium, Chloride, Carbon Dioxide Total, Urea Nitrogen, Blood (BUN), Creatinine Blood, Glucose, Calcium, Protein, Albumin, Alkaline Phosphatase (ALP), Aspartate Transaminase (AST), Bilirubin Total, Alanine Transferase (ALT), Globulin, Bilirubin Direct, Cholesterol, Triglyceride, LDL Cholesterol (Direct), HDL Cholesterol, Non-HDL Cholesterol, Lipase, Lactic Acid, CK-MB, Myoglobin, Troponin I, Thyroid Stimulating Hormone. Some rows vanish in the filtered view when no entries are present.

Bottom: **Viewing: ~6 d**, **Time Filter: All Results ▼**; date endpoints approximately **12:31 9/19/2021** and **01:00 9/13/2021**. Cyan outline around the narrow timeline with green and purple context marks. Three circular arrow/step buttons to right and a horizontal slider. Their exact individual navigation increments are unshown; do not implement them as media playback merely because they resemble play buttons.

### 10.4 Chemistry-only data, image 11

Dates include 9/19/21 12:30, 9/19/21 10:00, 9/18/21 15:00, 9/18/21 11:00, 9/13/21 13:00, 7/14/21 03:16, 03:12, 03:01. Bottom reads **Viewing: ~67 d**. Main chemistry values transcribed below; ! means the screenshot renders the value red with a flag. Dash means no visible value in that selected column, not a clinical zero.

| Test | 9/19/21 10:00 | 9/18/21 11:00 | 9/13/21 13:00 | 7/14/21 03:16 |
|---|---:|---:|---:|---:|
| Sodium | 140 | 138 | 140 | — |
| Potassium | 3.8 | 3.6 | 4.1 | — |
| Chloride | 100 | 87 ! | 105 | — |
| Carbon Dioxide Total | 30 | 35 ! | 24 | — |
| Urea Nitrogen, Blood (BUN) | 21 | 114 ! | 10 | — |
| Creatinine Blood | 1.20 | — | 0.6 | — |
| Glucose | 98 | 130 ! | 101 | — |
| Calcium | 8.9 | 8.2 ! | 8.8 | — |
| Protein | 8 | 6.5 | — | 6 |
| Albumin | 4 | 2.7 ! | 3.5 | 4 |
| Alkaline Phosphatase (ALP) | 50 | 197 ! | 58 | 60 |
| Aspartate Transaminase (AST) | 40 | 119 ! | 23 | — |
| Bilirubin Total | 1 | 3.8 ! | 0.6 | 0.6 |
| Alanine Transferase (ALT) | 53 | 82 ! | 32 | — |
| Globulin | — | — | — | 2 |
| Bilirubin Direct | — | — | — | 0.2 |
| Lipase | — | — | 84 | — |
| Thyroid Stimulating Hormone | — | — | 0.4 | — |
| Vitamin D, 25 Hydroxy | — | — | 47 ! | — |

Additional visible entries: Lipase **85** at 7/14/21 03:12; **Negative** text in Glucose and Protein rows at 7/14/21 03:01. These unusual placements are reference data, not instructions to combine different clinical specimen concepts. Lactic Acid values across the first four dates: **0.6**, **0.8**, **0.7**, **0.9**. Misc. Chemistry contains PSA Screen (blank) and Vitamin D, 25 Hydroxy. Cholesterol, Triglyceride, LDL Cholesterol (Direct), HDL Cholesterol, Non-HDL Cholesterol remain blank in the visible area.

### 10.5 Hematology-only data, image 12

Date columns: **9/19/21 10:00**, **9/18/21 11:00**, **9/13/21 13:00**, **7/12/21 15:51**, **10/31/19 10:51**, **1/11/17 09:10**, **1/11/17 08:48**, **8/28/13 11:55**. Year labels 2021, 2019, 2017, 2013 group the columns. Bottom reads **Viewing: ~8 yr**.

| CBC row | 9/19/21 | 9/18/21 | 9/13/21 | 7/12/21 | 10/31/19 | 1/11/17 09:10 | 1/11/17 08:48 | 8/28/13 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| White Blood Cell Count | 9.8 | 9.1 | 10.6 | 10.1 | — | — | — | 3.3 ! |
| Red Blood Cell Count | 2.94 ! | 2.91 ! | 5.0 | 4.29 | 6.07 ! | 3.92 ! | 4.51 | — |
| Hemoglobin | 9.3 ! | 9.2 ! | 13.8 | 14.3 | 15.3 | 11.8 ! | 13.6 | 14.4 |
| Hematocrit | 28.7 ! | 28.7 ! | 44 | 41.8 | 49.2 | 35.7 ! | 41.7 | 42 |
| MCV | 98.4 | 98.4 | 98 | 97.6 | 81.2 | 91.2 | 92.4 | 87.6 |
| MCH | 31.5 | 31.5 | 34 ! | 33.4 ! | 25.2 ! | 30.1 | 30.2 | 30.6 |
| MCHC | 32.1 | 32.1 | 35 | 34.3 | 31.1 ! | 33 | 32.6 | 34.2 |
| RDW | 16.5 ! | 16.5 ! | 13 | 12.7 | 15.9 ! | 14.6 | 16.2 ! | 13.5 |
| Platelet Count | 237 | 237 | 220 | 233 | 155 | 109 ! | 136 | 142 |
| MPV | — | — | 10 | 9.8 | 11.2 ! | 10.1 ! | 9.6 | 9 |

Group titles truncate as **COMPLETE BLOOD CO…**, **AUTOMATIC DIFFEREN…**, then **MANUAL DIFFERENTIAL**.

| Automatic differential | 9/19/21 | 9/18/21 | 7/12/21 | 10/31/19 | 8/28/13 |
|---|---:|---:|---:|---:|---:|
| Neutrophils % Auto | 67.0 | 67 | 77.3 | 69.6 | 27.9 |
| Lymphocytes % Auto | 12.8 | 12.8 | 11.9 | 20.2 | 60.5 |
| Monocytes % Auto | 12.8 | 12.8 | 8.2 | 8.6 | — |
| Eosinophils % Auto | — | — | 2.1 | 1.1 | — |
| Basophils % Auto | — | — | 0.5 | 0.5 | — |
| Neutrophils Abs Auto | 6.10 | 6.10 | 7.8 | 6.40 | — |
| Lymphocytes Abs Auto | 1.2 | 1.2 | 1.2 | 1.9 | — |
| Monocytes Abs Auto | 1.2 ! | 1.2 ! | 0.8 | 0.8 | — |
| Eosinophils Abs Auto | 0.5 | 0.5 | 0.2 | 0.1 | — |
| Basophils Abs Auto | 0.10 | 0.10 | 0.10 | 0 | — |

Manual differential: Monocytes % **7.2** at oldest date; Eosinophils % **6.0**, **6.0**, and oldest **3.5**; Basophils % **1.4**, **1.4**, and oldest **0.9**. Values are best-effort from compressed images; verify against source crops before treating them as exact test fixtures. Units and reference ranges are not visible and must not be invented as screenshot facts.

### 10.6 Micro & Infe… state, image 13

Only that category is selected. Grid body is blank. Prior date headings remain. Timeline still spans roughly 2013–2021. This could be a no-data state or a transitional capture; the screenshot alone cannot distinguish them. Reference replay should match the blank state. A general interactive mode can use a labeled empty state, but that would be a deliberate deviation from pixel fidelity.

### 10.7 Point of Care state, image 14

Dates: **9/13/21 01:00**, **12/4/20 07:47**, **2/2/17 06:12**, **2/1/17 23:00**, **2/23/14 23:00**. Group **ALL POC**. Rows:

- POC INR: **2.3**, **2.3** in the two 2017 columns.
- POC OCCULT BLOOD FECES: **Negative**, oldest column.
- POC SP GRAVITY: **1.005 !**, 2020 column.
- POC URINALYSIS-DIPSTICK: red circled alert indicator; exact underlying result not legible.
- Spirometry rows: **FEV1 2.54**, **FEV1 % PRED 84%**, **FVC 3.07**, **FVC % PRED 80%**, newest column. The heading above these is obscured by the tooltip.

The data grid only occupies x≈367–1017. To its right, a white panel contains a teal calendar/clock illustration and **You're viewing all available results.** The bottom timeline spans **9/13/2021** to **2/23/2014**. Preserve the narrower table and end-of-data panel; do not stretch sparse values across the whole workspace.

## 11. Notes browser: images 15–19

### 11.1 Main toolbar and category tabs

Heading **Notes** at x≈170,y≈132. Toolbar y≈174:

| Control | General role / evidence |
|---|---|
| New Note | Start a new encounter-associated clinical note [S7]. Exact click between 15 and 16 inferred. |
| Create in NoteWriter | Structured note-authoring route; specific form unshown [S7]. |
| Cosign Note | Review/sign another author's note where permitted [S8]. |
| Legend | Explain note-status indicators; popup unshown. |
| Filter | Restrict notes; dialog unshown. |
| My Last Note | Jump to user's most recent note, inferred; disabled-looking here. |
| Mark All as Not New | Clear newness indicators, inferred from label. |
| Refresh | Reload note list. |
| Reset Notes Activity Cache | Visible technical action; exact effects unverified. Preserve label, do not pretend it deletes notes. |

Category tabs, in order: **All Notes**, **H&P**, **Progress**, **Nursing**, **Procedures**, **Consults**, **TRNS/DC Sum**, **Allied Health**, **ED Notes**, **Care Plan**, **ACP**, **Incomplete**. All Notes is selected with a thin teal top edge. These are filters over note types, not separate patients.

Below: **Number of notes shown: 16 out of 16. All loaded.** Pale yellow notice: **There are new updates. Sort by new notes**. Notes have independent service time and filing time; preserve both metadata labels.

### 11.2 Note list

List x≈180–539, width≈359; starts y≈261. Sorting row: **Sort:** **Date** active cyan, **Note Type**, **Service**, **More ▼**, then small sort/settings icons. Month header **September 2021** with collapse chevron.

Each note entry is about 75–85 px tall, with round avatar at left, author name in teal/gray, professional role, service, note type on right, Date of Service, File Time, and optional status. Selected entry has cyan fill and a strong teal left strip. List has its own vertical scrollbar and a bottom horizontal scrollbar.

Visible entries in order, with truncated names retained:

| Author label | Role/service visible | Note type/status visible |
|---|---|---|
| Hamilton, Beatric… | *PHYSICIAN…; Critical Care… | Progress Note; gray entry with ×-like marker |
| **Hensley, Andrea L** | *PHYSICIAN…; Internal Medi… | **Progress Notes; Addendum**, selected |
| Bajorek, Sarah, … | .PHARMACIST / PHARMACIST | Best Poss Rx H… |
| Basilio, Roxann… | .NURSE: (R… | Nurse Transfer Note |
| Chang, Gregory … | *PHYSICIAN…; (A) Neurology | Progress Note |
| Griffin, Brooke | *PHYSICIAN… | Consult… |
| Guingab, Eva S… | .NURSE: (R… | Nurse Assessment |
| Chang, Gregory … | *PHYSICIAN…; (A) Neurology | H&P |
| Mai, Cherry G, RN | .NURSE: (R…; (A) Gastro In… | Nurse Assessment |
| Troppmann, Kat… | Partially hidden by presenter | Op Note, best-effort reading |
| Mai, Cherry G, RN | Partially hidden | OR Nursing… |
| Additional entries | Below/behind overlay | Do not invent authors for remaining count. |

### 11.3 Selected note reader

Image 15: x≈551–1510. Images 16–19: x≈551–1255 because editor widens. Toolbar: **Addendum**, **Copy**, **Cosign**, **Attest**, **Delete**, **Sign**, **Route**. Several disabled/light gray. Under it: tiny navigation, binoculars, printer, copy/document icons; zoom controls at right. General addendum and cosign purposes are verified [S8], but role-dependent enabled states must follow each reference image.

White document body with generous internal left margin compared with the compact toolbars. Header:

- **Hensley, Andrea L**.
- **\*PHYSICIAN: FACULTY**.
- **Internal Medicine Consult**.
- **Progress Notes** / **Addendum**.
- **Date of Service: 09/18/21 1454**.
- Links **Expand All** and **Collapse All**.

Visible body text:

> My note reflects my evaluation of the patient at approximately 12:00 today.
>
> I reviewed the note below of the Trauma and Emergency Surgery resident. I personally saw the patient, repeated selected aspects of the history and physical examination, and reviewed relevant laboratory and imaging findings. I discussed the assessment and plan with the resident and nurse practitioner team, with which I agree.
>
> Report electronically signed by:  
> Pat Hamilton, MD  
> Attending Physician  
> PI #06570  
> Pager 726-5678

Then **Date of Service: 4/3/2018**. Underlined **GENERAL INFORMATION**: Patient Zach; MRN: 7000004; DOA: 3/31/2018 2:15 PM; LOS: LOS:. Underlined **IDENTIFYING DATA / CHIEF COMPLAINT**. **Pertinent PMH/PSH:** and Past Medical History. Table Diagnosis / Date:

- Acute appendicitis with generalized peritonitis — 1/17/2018.
- Italic indented text: Added automatically from request for surgery 2444.
- Acute pulmonary embolism — 2/22/2018.

Then **Past Surgical History** with collapse/expand chevron; **Procedures:**; lower table partly visible in image 15 with Nutrition: NPO and IVF: NaCl 0.9% IV CONTINUOUS text. The rest is clipped.

This document contains Patient Zach/MRN 7000004 while the open chart is Aneone Xxteshim/MRN 9301254. It also mixes 2018 and 2021 dates and a Hensley header with Pat Hamilton signature. These are observed practice/template inconsistencies. Keep the selected-note body as an independent historical sample rather than deriving it from current demographics.

### 11.4 Transfer Orders sidebar, image 15

Approximately x=1534–1914, y=129–1079. Top tab **Transfer Orders ▼** active. Inside: **Transfer Order Rec** selected, **Order Sets**, **Options ▼**. Pale disabled **Edit Multiple**. Search placeholder **Place transfer orders, order sets, or pathways**; **+ New** at right. Below: dropdown **Standard**, disabled **Next**. Large centered clipboard illustration and **No Orders**.

Footer: pale **Remove All**, **Save Work**, **Sign & Hold**, and signing-related text at right, partly clipped/obscured. Exact last label is not reliably readable.

General transfer-order context concerns movement or service change [S11]. This pane is an order-reconciliation workspace; it is not the patient transportation dispatch interface. The reference shows no order creation, so no specific medication reconciliation decisions can be inferred.

## 12. Right-side My Note editor

### 12.1 Blank existing editor, images 7–14

Right pane x≈1280–1919. Heading **My Note**; upper-right small square buttons with person/check-looking, tag-looking, and book-like pictograms. Their tooltips are not visible. Note metadata line: **H&P · (A) Medicine - Wards 1 · 9/24/2022 1751**. Collapsed details chevron at right.

Formatting row includes star, font size **12** dropdown, **B**, **A** with colored underline/dropdown, indentation arrows, list/alignment-like controls, speech-bubble/lookup-like icons, green plus, **Insert SmartText** field/button, yellow previous/next arrows, list/wand-like glyph, green refresh, blue downward arrow. Preserve appearance/order; do not assign unsupported shortcuts to every tiny icon.

White editor border begins around x=1297,y=262 and ends around y=1027. Empty body is a large uninterrupted white rectangle. Bottom action bar aligns buttons right: **Pend**, **Share**, **Sign**, **Cancel**. Share is present in these states but absent from some later new-note states.

### 12.2 Expanded note details, image 16

Heading My Note; subheading **Note Details**. Fields:

| Field | Visible value | Approximate placement |
|---|---|---|
| Date of Service | 9/24/2022 | Left side of details row, x≈1402 |
| Time | 1813 | Adjacent to date, x≈1507 |
| Type | Placeholder Note Type | Right side, x≈1657; blue focus border |
| Service | (A) Medicine … | Second row left; lookup magnifier |

Formatting toolbar shifts downward to y≈278. Blank editor starts y≈294. Bottom buttons: **Pend**, **Sign**, **Cancel**. The current note reader remains selected at center; opening the authoring pane does not replace the historical document.

### 12.3 Cosigner, images 17–18

Type is **H&P**. Additional field **Cosigner:** on second row to right of Service. Query **mithu** with blue focus border, lookup magnifier. Dropdown floats under field, x≈1557,y≈253,w≈265,h≈73; thin dark outline and shadow. Gray header **Recent**; white result row **MOLLA, MITHU [510152481]**.

Verified purpose: the chosen cosigner can review/attest/sign after the author signs, with routing and status controlled by the installation [S8]. Merely typing a name is not proof that a cosigner has been selected; the screenshot shows suggestions, not completed routing. Proposed simulator behavior: select the result to store the provider ID and display name; retain it with the draft; emulate review status locally after signing. No external message should be sent.

### 12.4 Template-filled editor, image 19

Details are collapsed again. Metadata line now **H&P · (A) Medicine - Wards 1 · 9/24/2022 1813**. The editor has a blue focus border and its own scrollbar. It is scrolled to a lower portion of a longer template; do not infer that Assessment & Plan is the first section of the whole note.

Visible content in order:

1. Horizontal rule.
2. Bold **ASSESSMENT & PLAN:**.
3. Pink **\*\*\*** wildcard.
4. Blank spacing.
5. Bold separator line **======== CHRONIC / STABLE / RESOLVED ========** (exact equals count approximate).
6. **FEN -** pink wildcard.
7. **Analgesia -** pink wildcard.
8. **Sedation -** pink wildcard.
9. **Thromboppx - {lovenox, or heparin if poor kidney function}**.
10. **HOB >30 degrees**.
11. **Ulcer ppx -** pink wildcard, followed by parenthesized template criteria: ventilation >48 hours; coagulopathy with platelet/INR/PTT thresholds; GI ulceration/bleeding in past year; TBI/spinal cord injury/burn; additional risk factors including sepsis, ICU duration, occult GI bleeding, steroid exposure, NSAID/antiplatelet use. This is a historical template transcription, not a recommended protocol.
12. **Glucose goal <180**.
13. **SBTs per protocol**.
14. **Bowel regimen -** pink wildcard; **(Last Bowel Movement: 03/27/18)**.
15. **Indwelling lines -** table with pale blue/gray rows: Urethral Catheter indwelling catheter 100% silicone 16 Fr (Active); Ureteral Catheter left ureter (Active); Peripheral IV over-the-needle catheter R antecubital 16 gauge (Active).
16. **De-escalate abx**.
17. Bold **Code status:** pink wildcard; **medical decision maker is** pink wildcard.
18. Bold **PRESENT ON ADMISSION**.
19. Question about five conditions present/suspected on admission: decubitus ulcer, infection from an intravascular device, infection due to an indwelling catheter, surgical site infection, or pneumonia.
20. Pink dropdown **List of POA conditions ▼**.
21. Signature block: **Conan S Liu, M.D.**; **Internal Medicine, PGY-2**; **PI: x3358 (TigerText preferred)** or similar abbreviated identifier line, partly overlapped by a small clipboard icon; exact prefix unresolved.

The sample provides no visible template name or dot phrase. Do not claim a specific SmartPhrase triggered it. The result could have come from a SmartText or SmartPhrase containing additional SmartTools.

### 12.5 SmartTools and editor behavior

Institutional sources distinguish four tools [S12, S13]: SmartText inserts a template; SmartPhrase expands a short dot-prefixed abbreviation; SmartLink pulls chart data; SmartList offers predefined choices. Templates can contain several kinds together. OHSU documents F2 navigation through unresolved choices/wildcards [S13].

Future simulator requirements, intentionally proposed where exact local Epic behavior is not shown:

- Insert a named simulator template through Insert SmartText. Clearly distinguish any invented template name from observed labels.
- Render *** as editable highlighted wildcard fields, not literal permanent pink decorations.
- Allow F2 to move to the next unresolved template field.
- Open selectable options for List of POA conditions; exact original option catalog is unknown.
- Keep linked line/device data visually distinct from free text, following the reference table styling.
- Pend saves an unsigned local draft; Sign changes the simulated note status; Cancel asks about unsaved changes if applicable. These are proposed completion semantics, not a claim about every Epic installation's visibility rules.
- Share, when present, should be a local simulated draft-sharing state; actual Epic visibility and permissions vary and were not verified for this installation.
- Prevent the simulator from presenting an incomplete wildcard-filled note as successfully finalized without explaining the unresolved fields. Exact production validation rules are unknown.
- Preserve text and metadata when switching main activities. The screenshots demonstrate the pane persists; autosave timing is a simulator design decision.
- Signed-note edits should be represented as addenda with status/history rather than silently rewriting the source document; general addendum purpose is verified [S8].

## 13. Functional map and boundaries

| User goal | Relevant visible control | Expected result | Evidence strength |
|---|---|---|---|
| Add an existing patient to a personal list | Add Patient | Patient Lookup, then list count seven→eight | Observed sequence |
| Preview patient information | Select row + lower report | 24-hour report under grid | Observed layout; image 6 contains a transient mismatch |
| Enter chart workspace | Open Chart or patient row | Storyboard + activity tabs + sidebar | Destination observed, exact gesture unshown |
| Read a compact patient overview | Summary / Rounding Report | Cards of reports, meds, devices, recent observations | Observed |
| Keep a private scratch note | Upper-left paper icon | Floating yellow My Sticky Note | Observed + general scope [S6] |
| Compare results over time | Results | Date-column table and category tree | Observed + [S5] |
| Restrict result types | Chemistry/Hematology/etc. | Category-specific matrix | Observed |
| Track newly reviewed results | Time Mark | Updated review cutoff/highlights | Verified general function [S9], click unshown |
| Browse past documentation | Notes and note list | Selected document at center | Observed + [S7] |
| Add documentation | New Note / My Note | Blank editor with details | Observed destination, gesture inferred |
| Select note category | Type field | H&P | Observed |
| Assign review responsibility | Cosigner lookup | Provider suggestion and eventual selection | Suggestion observed; general purpose [S8] |
| Insert reusable note content | SmartText/SmartPhrase route | Template with editable fields and data | End state observed; tool distinction verified [S12,S13] |
| Handle a transfer's orders | Transfer Orders | Reconciliation/sidebar workflow | Empty state observed; broad context [S11] |

A faithful simulator should not turn every visible button into the same generic popup. For known activities, provide the correct distinct destination. For local resources and unseen screens, retain accurate labels and mark behavior as pending evidence in the build specification. The reference does not justify fabricated full screens for CURES, CRC, IM MMQS, Care Plans Guide, or Data Validate.

## 14. State that the future simulator must preserve

This is a conceptual behavior model, not implementation code.

| State | Scope | Why it matters |
|---|---|---|
| Practice user and department | Whole session | CONAN LIU and inpatient medicine title persist. |
| Open patient workspaces | Session | Multiple patient tabs coexist. |
| Current personal list and membership | User/list | Adding changes count and tree without creating a patient record. |
| Selected list row | Patient Lists | Controls row highlight, shortcuts, and report context. |
| Main chart activity | Open patient workspace | Summary/Results/Notes switches central content. |
| Sidebar mode and width | Workspace | Edit Note and Transfer Orders independently change. |
| Sticky-note text/open position | User + patient | Popup persists through activity changes. |
| Result category selection | Patient/result view | Chemistry/Hematology/POC produce distinct rows and date ranges. |
| Result time filter and viewport | Result view | Six-day, 67-day, eight-year, all-available views differ. |
| Review/time-mark cutoff | User + patient | Newness is separate from clinical values. |
| Selected historical note | Notes view | Hensley note remains visible while new note is authored. |
| Draft note body/details | Patient + encounter + author | Type, cosigner, date, and text must survive navigation. |
| Scroll positions | Each independent pane | Reader/editor/tree/results can be scrolled separately. |

The screenshot set supports a linear reference replay. A later free-navigation mode should use consistent current-patient context, while a screenshot-replay fixture can retain the image-6 lower-report lag and contradictory demonstration data.

## 15. Fidelity checklist for later implementation

### Geometry and appearance

- [ ] Reference canvas near 1920×1080; account for cropped title bar in images 1–2.
- [ ] Red diagonal-pattern menu, dark workspace tabs, cool-gray body, white report/document surfaces.
- [ ] Patient Lists tree ≈225 px; chart storyboard ≈167 px.
- [ ] Standard note sidebar ≈640 px; narrower Transfer Orders sidebar in image 15.
- [ ] Dense toolbar and table typography; square thin-bordered buttons; correct disabled states.
- [ ] Cyan patient selection and strong-blue Open Patients selection are different styles.
- [ ] No screen-darkening overlay behind Patient Lookup.
- [ ] Sticky note overlays shell at upper right while its trigger remains upper left.
- [ ] Accurate card positions and blank gray gaps in Rounding Report.
- [ ] Results grid row heights, cyan data cells, thin teal rules, red abnormal flags, blank intersections.
- [ ] Notes list, reader, and editor remain separate scroll regions.
- [ ] Preserve truncation and ellipses at the observed widths.
- [ ] Do not include the video presenter's face overlay or Subscribe watermark as app UI. They are recording artifacts. Their covered regions remain evidence gaps.

### Demonstrated interactions

- [ ] Add Patient opens lookup with Name/MRN focused.
- [ ] Search 9301254; add Xxteshim exactly once; count seven→eight.
- [ ] Show patient-row shortcuts and handoff tooltip.
- [ ] Open patient Summary with persistent storyboard.
- [ ] Open/type/close/reopen sticky note; preserve across activity switches.
- [ ] Results opens correct initial all-category state.
- [ ] Chemistry, Hematology, Micro & Infe…, POC each reproduce their respective screenshot.
- [ ] Show POC tooltip and all-available-results panel.
- [ ] Notes opens 16-note browser with Hensley sample selected.
- [ ] Support right-pane switch from Transfer Orders to My Note.
- [ ] New note details accept H&P and cosigner search mithu.
- [ ] Suggest MOLLA, MITHU [510152481].
- [ ] Insert an explicitly named simulator template matching image 19's visible lower section.
- [ ] Wildcards and choice fields are interactive; draft survives navigation.

### Behavior not established by these references

- Exact menus of Edit List, More, Personalize, Epic, report selectors, note filters, and Options.
- Full screens behind Chart Review, Orders, Intake/Output, Navigators, Teams, History, Flowsheets.
- Patient search results/acceptance dialog beyond the captured Open Patients list.
- Exact search matching rules and role-based restrictions.
- Sticky-note auxiliary icon meanings and persistence timing.
- Result cell detail popup, graph view, reference units/ranges, timeline button increments.
- Note template name, hidden upper template content, complete POA choices, exact signature prefix.
- Pend/Share visibility policies, production signing validation, exact routing behaviors.
- Meaning of purple numbered badges and local documentation status icons.
- Clinical data beneath recording overlays or beyond scroll boundaries.

These are explicit limitations, not permission to omit the visible controls. Match their visual footprint while keeping their future functionality distinguishable from documented behavior.

## 16. Public research references and claim coverage

Research checked 4 November 2026. These are institutional/public references. Some pages link to staff-only handouts or e-learning; this specification uses publicly accessible descriptions and does not claim access to restricted training. Current documentation can explain a feature without matching the older screenshot design.

| ID | Source | What it supports |
|---|---|---|
| S1 | [University of Iowa — Hyperspace (Epic Basics)](https://epicsupport.sites.uiowa.edu/epic-resources/hyperspace-epic-basics) | Hyperspace platform, workspace/navigation concepts, Patient Station/Open Chart, personalization, reports and printing. |
| S2 | [University of Iowa — Patient Lists (My List)](https://epicsupport.sites.uiowa.edu/epic-resources/patient-lists-my-list) | Patient Lists assembles and displays lists; list personalization context. |
| S3 | [University of Iowa — Patient Reports](https://epicsupport.sites.uiowa.edu/epic-resources/patient-reports) | Reports available in multiple locations; report toolbar and default report customization. |
| S4 | [University of Iowa — Chart Review](https://epicsupport.sites.uiowa.edu/epic-resources/chart-review) | Longitudinal encounter, lab, imaging, procedure, medication reports; filters and sidebar pinning. |
| S5 | [University of Iowa — Results Review](https://epicsupport.sites.uiowa.edu/epic-resources/results-review) | Diagnostic results over time, expandable groups, reference ranges, graph/flowsheet views. |
| S6 | [University of Iowa — Sticky Notes](https://epicsupport.sites.uiowa.edu/epic-resources/sticky-notes) | Personal versus customized shared sticky-note scope; distinction from formal clinical notes. |
| S7 | [University of Iowa — Notes](https://epicsupport.sites.uiowa.edu/epic-resources/notes) | Clinical documentation, related encounter, Notes/NoteWriter/navigator authoring routes. |
| S8 | [University of Iowa — Editing & Reviewing Notes](https://epicsupport.sites.uiowa.edu/epic-resources/editing-reviewing-notes) | Addenda, attribution, cosigner review, cosign-needed status and routing. |
| S9 | [Johns Hopkins — Epic Tips, April 1, 2022](https://medicine-matters.blogs.hopkinsmedicine.org/2022/04/epic-tips-april-1-2022/) | Results Review wrench settings, new-result highlighting, Time Mark, navigation and unresulted orders. |
| S10 | [University of Iowa — Orders](https://epicsupport.sites.uiowa.edu/epic-resources/orders) | Inpatient order review/entry and order-set concepts. |
| S11 | [University of Iowa — Admit, Discharge, and Transfer Orders](https://epicsupport.sites.uiowa.edu/epic-resources/admit-discharge-and-transfer-orders) | General transfer-order and reconciliation context; local details vary. |
| S12 | [University of Iowa — SmartTools](https://epicsupport.sites.uiowa.edu/epic-resources/smarttools) | Definitions of SmartText, SmartPhrase, SmartLink, SmartList. |
| S13 | [OHSU — SmartTools Quick Guide](https://www.ohsu.edu/sites/default/files/2019-08/SmartTools%20Quick%20Guide%2001-14-18.pdf) | Template insertion, dot-phrase expansion, F2 wildcard/SmartList navigation. |

## 17. Final scope statement

The supplied references establish three major working surfaces—Patient Lists, patient chart Summary/Results, and Notes—with a shared shell, a separate sidebar, and a persistent sticky-note overlay. This document records every legible major control, the observed workflow order, approximate geometry, measured and estimated colors, visible sample data, source-backed feature purposes, and unresolved details. It is the baseline for the later build when Mahmud explicitly asks to start coding.
