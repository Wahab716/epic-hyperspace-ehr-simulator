**Keep the existing simulator, but expand it into a healthcare IT training environment with three connected areas: Clinical, IT Support, and Analytics.** The biggest missing piece is a system where you can investigate a problem, inspect evidence, make an authorized change, and verify the outcome.

Your goal should be **credible entry-level skills and interview readiness**. A simulator can help substantially, but it cannot reproduce proprietary Epic configuration tools or establish official Epic proficiency.

I researched additional requirements. Epic’s technical-support career description emphasizes understanding configuration, workflows, and training together. Employer postings also emphasize incident resolution, requirements gathering, testing, documentation, upgrades, and communication—not simply navigating charts. [Epic Careers](https://careers.epic.com/jobs/technical-solutions-engineer/?utm_source=chatgpt.com)

Everything below is a **proposed expansion specification**. No code changes in this step.

**1. Preserve the current screenshot-based interface**

The existing clinician workspace should retain:

- Red global toolbar and dark workspace tabs.
- Patient Lists with the lower report preview.
- Patient lookup, chart tabs, and left patient storyboard.
- Summary cards and independent right sidebar.
- Floating private sticky notes.
- Results Review with category filters and date columns.
- Notes browser, historical document reader, and separate authoring pane.

Add a separate training launcher with **Clinical / IT Support / Analytics** choices. Keep scores, instructions, and hints in a collapsible training panel so they do not clutter the recreated Hyperspace interface.

**Accuracy must have three clearly identified levels:**

| Level | Meaning |
|---|---|
| Screenshot recreation | Appearance and behavior directly supported by your reference images |
| Documented workflow simulation | General behavior supported by institutional Epic documentation |
| Educational approximation | Our own support consoles, configuration tools, datasets, and exercises |

We should not invent an administrative screen and label it an exact Epic tool.

**2. Clinical environment: complete the patient journey**

The purpose is to understand what clinicians are trying to accomplish and where a workflow can fail.

| Area | Required functionality | Practice exercise |
|---|---|---|
| Patient identification | Search by identifiers; distinguish similar names; inspect demographics | Select the correct patient among similar records |
| Registration | Create a fictional patient; validate required fields; flag possible duplicates | Register a patient without creating a duplicate |
| Scheduling | Appointment creation, rescheduling, cancellation, check-in, no-show | Resolve an appointment attached to the wrong visit type |
| Encounter management | Separate patient record from individual visits; encounter statuses | Find documentation recorded under the wrong encounter |
| Admission/transfer/discharge | Admission, unit/bed assignment, transfer, discharge | Transfer a patient while preserving encounter history |
| Chart review | Notes, conditions, allergies, medications, results, history | Assemble a concise chart summary |
| Documentation | Draft, pend, sign, cosign, addendum; author and service timestamps | Correct documentation using an addendum |
| Orders | Medication, laboratory, imaging, procedure requests | Find why an order has not progressed |
| Medication reconciliation | Compare home and encounter medication lists; record decisions | Identify an unresolved reconciliation item |
| Medication administration | Scheduled doses, administration events, held/refused statuses | Distinguish an order from an administered dose |
| Specimens and results | Collection, receipt, processing, final and corrected results | Trace an ordered test to its final result |
| Result follow-up | Review status, assigned reviewer, pending follow-up | Find a result without completed follow-up |
| Discharge | Checklist, summary, medication reconciliation, instructions, follow-up | Complete a simulated discharge |
| Patient communication | Separate internal messages from patient-facing communication | Identify the correct communication destination |

These should be **stateful workflows**. Placing a laboratory order should create an order record; collecting its specimen should advance that same order; receiving a result should update the corresponding chart.

Patient identification, test-result follow-up, system management, and downtime planning deserve explicit exercises. They are major subjects in the federal SAFER Guides. [healthit.gov](https://healthit.gov/clinical-quality-and-safety/safer-guides/?utm_source=chatgpt.com)

**Clinical realism requirements**

- A patient can have multiple encounters.
- Patient-level information and encounter-level information remain distinct.
- Ordering a medication does not automatically administer it.
- Ordering a test does not automatically produce a result.
- Signing a note does not automatically discharge the patient.
- Removing someone from a personal patient list does not delete their record.
- Corrected results retain the earlier result and correction history.
- Signed documentation retains authorship and revision history.
- Empty, pending, canceled, and unavailable are separate states.

For training, clinical decisions should be supplied by the scenario. You should be assessed on workflow and support reasoning, not prescribing or diagnosing.

**3. IT Support environment: the largest expansion**

This needs to feel like working a support queue.

The support workspace should contain:

| Screen | Required contents |
|---|---|
| Ticket queue | Ticket ID, priority, affected service, requester, assigned team, status, age |
| Ticket detail | Reported symptoms, timeline, reproduction steps, impact, attachments |
| User directory | Fictional user, role, department, account status, approved access |
| Session viewer | Login attempts, device, session state, selected department |
| System health | Availability, errors, latency, affected components |
| Application logs | Timestamp, severity, correlation ID, component, sanitized message |
| Interface queue | Message status, retries, acknowledgments, failures |
| Audit viewer | Who accessed or changed what, when, and in which context |
| Configuration history | Current setting, previous value, change request, effective date |
| Knowledge base | Troubleshooting articles, workarounds, escalation routes |
| Change workspace | Proposed change, approval state, testing, rollback |
| Resolution editor | Cause, action, validation, communication, prevention |

**Required troubleshooting method**

Every ticket should require you to:

1. Clarify the symptom and impact.
2. Identify who and what are affected.
3. Check the correct patient, encounter, department, device, and environment where relevant.
4. Reproduce safely or gather sufficient evidence.
5. Compare working and failing cases.
6. Form a hypothesis.
7. Inspect evidence that can support or reject it.
8. Apply an authorized fix or escalate.
9. Verify the original workflow.
10. Document the outcome in plain language.

The simulator should reward diagnosis supported by evidence—not clicking through every possible tool.

**Initial support scenario catalog**

| Scenario | What you should investigate |
|---|---|
| Doctor cannot log in | Account state, authentication failure, service availability |
| One workstation cannot launch the application | Local device/session issue versus wider outage |
| User signs in but sees the wrong workspace | Department, role, personalization, environment |
| Nurse cannot perform an action | Approved role and relevant permission |
| User requests access outside their role | Authorization and escalation, not automatic access granting |
| Patient cannot be found | Identifier, spelling, search scope, duplicate records |
| Patient missing from a list | Membership, list filters, location, encounter status |
| Note appears missing | Encounter, note status, author, filters, filing time |
| Cosigner cannot find a note | Selected cosigner, signing status, routing state |
| Order appears missing | Encounter, signature/release status, filters, cancellation |
| Lab result is absent | Order, specimen, interface delivery, result association |
| Result exists but is not visible to one user | Filters, context, permissions |
| Duplicate result appears | Retries, message identity, duplicate-processing protection |
| Wrong patient association | Identity mapping and escalation |
| Report shows stale data | Source freshness, failed load, report cache |
| Report count is unexpectedly high | Join multiplication, filters, population definition |
| Label printer fails | Device selection, queue, workstation mapping |
| Application becomes slow | Scope, timing, recent changes, component latency |
| Upgrade breaks a workflow | Reproduction, regression evidence, rollback decision |
| EHR becomes unavailable | Incident escalation and downtime procedure |

Not every case should be solvable by you. Correct escalation is a successful outcome when the scenario exceeds the role’s authority.

**4. Permissions, privacy, and auditability**

Permissions must affect actual simulated behavior, rather than just changing a role label.

Suggested roles:

- Registration clerk.
- Nurse.
- Resident.
- Attending.
- Help-desk technician.
- Application analyst.
- Reporting analyst.
- Access administrator.

Examples:

- Registration can update permitted demographics but cannot sign clinical notes.
- A reporting analyst can query authorized training datasets without receiving unrestricted chart-editing privileges.
- A technician can inspect account status but cannot grant arbitrary clinical access.
- A resident’s note can require cosignature under the scenario’s rules.

Every relevant operation should create an audit event.

Teach minimum-necessary access through specific scenarios rather than a generic checkbox. HHS describes limiting applicable uses, disclosures, and requests for protected information to what is necessary for the purpose, with context-dependent requirements. [HHS.gov](https://www.hhs.gov/hipaa/for-professionals/privacy/guidance/minimum-necessary-requirement/index.html?utm_source=chatgpt.com)

**5. Application analyst work: configuration, testing, and releases**

This is a separate skill from help-desk troubleshooting.

Employer descriptions explicitly include configuration, testing, validation, maintenance, documentation, and go-live support. [hctec.breezy.hr](https://hctec.breezy.hr/p/92588b909dd801-epic-certified-application-analyst-various-modules?utm_source=chatgpt.com)

Add a fictional configuration workspace for:

- Department-specific defaults.
- Role-to-activity access.
- Required documentation fields.
- Note templates.
- Order catalog availability.
- Routing destinations.
- Patient-list definitions.
- Report parameters.
- Alert conditions.
- Effective dates and version history.

These would be **educational configuration tools**, not replicas of proprietary Epic build screens.

A configuration exercise should follow this sequence:

| Stage | Required artifact |
|---|---|
| Request | Clear business problem |
| Requirements | Expected behavior and acceptance criteria |
| Impact assessment | Affected users, workflows, dependencies |
| Configuration | Proposed change in a training environment |
| Testing | Positive, negative, permission, and regression cases |
| User acceptance | Recorded stakeholder validation |
| Release | Approved deployment plan |
| Recovery | Rollback procedure |
| Follow-up | Post-change verification and documentation |

Example: “A new clinic needs a required field in its intake workflow.” You must apply it only to the intended clinic and verify that other departments still work.

**6. Interfaces and integrations**

Add an interface laboratory so you can follow information between systems.

Epic publicly supports standards-based integration and provides FHIR documentation and test environments. An optional later integration can use its developer sandbox; that is different from obtaining a full clinical training environment. [open.epic.com](https://open.epic.com/Interface/FHIR?utm_source=chatgpt.com)

The proposed lab should include:

| Component | What you practice |
|---|---|
| Message viewer | Read a fictional incoming/outgoing message |
| Routing rules | Determine the intended destination |
| Mapping table | Translate local codes and identifiers |
| Acknowledgment viewer | Distinguish accepted delivery from rejection |
| Error queue | Investigate failed messages |
| Controlled retry | Reprocess safely without creating duplicates |
| API request console | Inspect request, response, status, and correlation ID |
| Authentication simulation | Expired token, missing scope, wrong environment |
| Data reconciliation | Compare source and destination records |

Required scenarios:

- A result fails because its test code is unmapped.
- A message references an unknown patient identifier.
- A duplicate delivery must not create duplicate clinical records.
- An API returns an authorization error.
- A request succeeds but retrieves the wrong encounter.
- A source system delivers a corrected result.
- An integration points to the wrong environment.
- The destination is unavailable and messages accumulate.

Teach both **message delivery** and **successful clinical association**. A technically accepted message can still fail to appear where the clinician expects.

**7. Analytics environment: actual SQL and data validation**

For BI-oriented roles, this should receive substantial development time.

A current employer-posted Cogito role calls for Reporting Workbench, Clarity, SQL, requirements analysis, and validation of reporting results. That is useful evidence of the skill cluster, though it is an experienced role—not a promise about entry-level hiring requirements. [Computer Task Group, Inc](https://careers.ctg.com/na/jobs/17479?lang=en-us\&utm_source=chatgpt.com)

**Distinguish the Epic concepts accurately**

| Concept | Training representation |
|---|---|
| Chronicles | Explain the operational data context; do not pretend our database is Chronicles |
| Clarity | Simulated extracted relational reporting dataset |
| Caboodle | Simulated curated warehouse with facts and dimensions |
| Cogito | The broader analytics environment |
| Reporting Workbench | Parameterized operational report exercises |
| Radar | Dashboard exercises |
| SlicerDicer | Cohort-selection and exploration exercises |

Epic describes Reporting Workbench as supporting operational reporting and Clarity as extracting data into a separate database. UC Davis identifies the broader Cogito tool family, while Michigan Medicine describes Caboodle as a curated enterprise warehouse. [epic.com](https://www.epic.com/mu/?utm_source=chatgpt.com)

**SQL workspace requirements**

- Executable SQL against a real training database engine.
- Schema browser and data dictionary.
- Query editor.
- Result table.
- Error messages.
- Saved queries.
- Query history.
- Explain-plan exercises where supported.
- Read-only permissions for reporting exercises.
- Expected-result comparison.
- Hidden test datasets so memorizing one result does not pass.

Use clearly labeled synthetic tables. Do not present invented table names as authentic Clarity schemas.

**Core training tables**

| Table | Represents |
|---|---|
| Patients | Patient identities |
| Encounters | Individual visits/admissions |
| Departments | Locations and services |
| Providers | Clinicians |
| Orders | Requests for medications/tests/procedures |
| Specimens | Collected samples |
| Results | Observations and revisions |
| MedicationAdministrations | Actual administration events |
| Notes | Documentation metadata and status |
| Appointments | Scheduled visits |
| Transfers | Location changes |
| Users / Roles / Permissions | Access model |
| AuditEvents | Access and changes |
| InterfaceMessages | Integration events |
| LoadRuns | Reporting extraction/load history |

**SQL exercise progression**

1. Filter and sort records.
2. Join patients to encounters.
3. Count encounters without counting patients twice.
4. Group by department.
5. Handle missing values correctly.
6. Include patients with no matching orders using outer joins.
7. Use conditional aggregation.
8. Use common table expressions.
9. Find the latest result with window functions.
10. Distinguish original and corrected results.
11. Identify duplicates.
12. Compare operational and reporting data.
13. Diagnose incorrect totals caused by joins.
14. Interpret query plans and improve an inefficient query.
15. Validate a report against a defined reference population.

**Reporting exercises**

- Daily census.
- Admissions and discharges.
- Length of stay using an explicitly defined calculation.
- Appointment no-show rate.
- Unsigned notes.
- Outstanding cosignatures.
- Orders without results.
- Result turnaround time.
- Interface queue backlog.
- Support ticket resolution time.

Each report must define its population, grain, time window, exclusions, numerator/denominator where applicable, refresh time, and intended audience.

**8. Reporting pipelines and freshness**

A dashboard should not instantly mirror every clinical action.

Introduce a simulated extraction/load pipeline:

- Operational records.
- Staging data.
- Reporting tables.
- Warehouse transformations.
- Dashboard refresh.

Allow controlled failures:

- Failed extraction.
- Partial load.
- Late-arriving result.
- Changed code mapping.
- Duplicate source record.
- Time-zone mismatch.
- Stale dashboard cache.
- Missing department mapping.

The learner should answer: **“Is the data absent at the source, delayed in transit, transformed incorrectly, or filtered out in the report?”**

That distinction is central to useful BI troubleshooting.

**9. General IT skills within the scenarios**

Do not make the simulator only about Epic terminology.

Include a focused technical workbench for:

- HTTP status codes.
- DNS and connectivity concepts.
- Authentication versus authorization.
- Browser/session/cache behavior.
- Application versus database versus integration failures.
- Log filtering.
- Timestamps and time zones.
- Reading JSON.
- Basic command-line diagnostics.
- SQL.
- Version control and change comparison.

Use simulated outputs or a restricted lab. Avoid suggesting that a beginner should run arbitrary commands or alter production databases to investigate a ticket.

**10. One connected fictional hospital**

The three environments should share data.

A single scenario could run like this:

1. A patient checks in.
2. A clinician places a laboratory order.
3. The specimen is collected.
4. The lab sends a result.
5. A mapping error prevents its appearance.
6. A clinician opens a support ticket.
7. You trace the failure and repair the training mapping.
8. You safely reprocess the message.
9. The result appears in the chart.
10. A scheduled reporting load updates the analytics dataset.
11. You confirm the result appears in a report.
12. You document the resolution.

This would be far more useful than three disconnected demonstration pages.

**11. Scored exercises and realistic feedback**

Every exercise should contain:

- A role and permissions.
- A starting system state.
- A user complaint or business request.
- Available evidence.
- One or more plausible causes.
- Allowed actions.
- Expected outcomes.
- Optional hints.
- A scoring rubric.
- A replayable event history.

Suggested scoring:

| Area | Weight |
|---|---:|
| Identifying impact and scope | 15% |
| Gathering relevant evidence | 25% |
| Diagnosis and explanation | 20% |
| Appropriate fix or escalation | 20% |
| Validation | 10% |
| Documentation and communication | 10% |

Do not score only speed. Penalize unsupported permission changes, wrong-patient actions, editing production-like data without authorization, and closing a ticket without verification.

Feedback should explain **why an action was appropriate or inappropriate** and show the evidence the learner missed.

**12. Documentation and communication practice**

Require useful written outputs:

- Ticket investigation notes.
- A plain-language update to a clinician.
- An escalation containing reproducible evidence.
- A root-cause summary.
- A knowledge-base article.
- A change request.
- A test plan.
- A report requirements document.
- A data-validation checklist.

Example resolution format:

> **Issue:** What the user experienced.  
> **Impact:** Who or what was affected.  
> **Cause:** Evidence-supported explanation.  
> **Action:** What changed and under what authorization.  
> **Validation:** How the original workflow was checked.  
> **Follow-up:** Remaining work or prevention.

These artifacts can become portfolio evidence alongside the simulator.

**13. Changes needed underneath the existing app**

For a serious expansion, browser-local storage should no longer be the sole system of record.

| Requirement | Purpose |
|---|---|
| Persistent database | Consistent records and relationships |
| Server-side authorization | Permissions actually enforced |
| Versioned records | Preserve changes and corrections |
| Audit history | Support investigations |
| Scenario snapshots | Reset one exercise predictably |
| Deterministic fixtures | Repeatable assessment |
| Background jobs | Reporting loads and interface processing |
| Failure injection | Realistic troubleshooting |
| Automated workflow tests | Catch broken cross-screen behavior |
| Data export | Download queries, reports, and exercise evidence |

Browser-local storage can still hold preferences, such as panel sizes and selected tabs.

**14. What to prioritize for your job goal**

You do **not** need equal mastery of every healthcare IT specialization.

| Target role | Highest-priority practice |
|---|---|
| IT support / service desk | Account and device troubleshooting, scope, tickets, escalation, communication |
| Epic application analyst | Workflow knowledge, configuration concepts, testing, permissions, change management |
| BI developer / reporting analyst | SQL, data models, reporting requirements, validation, pipelines, dashboards |
| Interface/integration analyst | Messages, mappings, APIs, authentication, queues, reconciliation |

I found third-party listings for Kaleida’s BI Developer I role, but did not verify its exact current requirements on an official Kaleida posting. We should tailor the final assessment to that actual posting before treating any certification or technology as mandatory.

**15. Practical build order**

| Phase | Deliverable |
|---|---|
| 1 | Correct shared patient/encounter model, persistent data, audit events |
| 2 | Complete clinical journey and meaningful workflow statuses |
| 3 | Ticket console, roles, logs, and 15–20 support scenarios |
| 4 | Executable SQL lab, data dictionary, and reporting exercises |
| 5 | Interface queue, mapping failures, APIs, and controlled retries |
| 6 | Configuration changes, testing, release, and rollback exercises |
| 7 | Connected capstones, scoring, progress tracking, portfolio exports |

For your seven-day preparation, I would emphasize the shared foundation, common support tickets, and SQL/report validation first. The complete environment can grow beyond that week.

**The completion standard should be:** you can investigate unfamiliar scenarios, explain your reasoning, recognize your authority limits, validate a solution, and document it clearly. Visual familiarity supports that goal; the connected exercises are what will make this substantially closer to real healthcare IT work.