# Scrolling correction

Root cause: the outer .shell used height:100dvh while main owned a nested overflow container. The embedded reference chart independently used a viewport-height .shell, body overflow:hidden and constrained chart descendants. This combination clipped lower content/controls at normal window sizes.

Changes: outer document owns vertical scrolling; shell and main grow naturally; reference chart shell and content sections grow with content; editor footer/status controls do not shrink; horizontal table/navigation overflow remains available. A ResizeObserver reports the reference app's natural height to the host, which verifies same-origin iframe sender and finite height before resizing. The observer measures the app rather than document viewport height, avoiding a resize feedback loop. Mobile titles wrap and reference horizontal scrolling remains available.

Verification: two regression checks cover effective CSS overrides and guarded frame/content sizing. TypeScript and original chart JavaScript syntax checks passed. Full automated suite: 29 tests passed. Production build/deployment recorded in delivery. Signed-in browser visual checks at different screen sizes remain unverified: the production browser previously displayed Sign in required. No browser viewport sweep is claimed.
