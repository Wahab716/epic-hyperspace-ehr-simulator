import {env} from 'cloudflare:workers';
import {processScheduledWorkspaces} from '../../../lib/training/background.mjs';
// This shared maintenance endpoint relies on the Site's owner-only dispatch boundary.
// Reassess authorization before ever widening the Site audience.
export async function POST(r:Request){
 const origin=r.headers.get('origin');if(origin&&origin!==new URL(r.url).origin)return Response.json({error:'Origin mismatch'},{status:403});
 return Response.json(await processScheduledWorkspaces(env.DB),{headers:{'Cache-Control':'no-store'}});
}
