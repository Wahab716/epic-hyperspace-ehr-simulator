# Connected historical chart implementation

Implemented since checkpoint 54913b0:
- Original Notes view renders shared signed historical imports, authored notes and addenda. Note filters and selection use shared record identities.
- Original Results grid renders shared results, with correction/review dialogs, prior values, revisions and patient association checks.
- Historical imports initialize when opening/selecting chart activities, once per patient.
- Notes-read uses a distinct server command.
- Historical category date arrays now match the displayed reference dates for chemistry, hematology and point-of-care rows. Missing values are not materialized as results.
- Written assessment requires scenario-specific evidence details; generic diagnosis receives capped credit and actionable feedback.
- Server scheduled-workspace processor creates hourly reporting jobs only for opted-in workspaces, preserves roles, retries concurrent writes and avoids repeated hourly loads. Owner-private maintenance endpoint supports unattended execution. Native scheduled handler also supplied; hosting schedule setup is recorded in delivery.

Verification: existing 19 tests passed; 2 additional category-fidelity/scheduling tests passed. TypeScript and JavaScript syntax checks passed. Production build and deployment recorded in delivery.

## Requirement status
| Specification area | Status / evidence |
|---|---|
| Original visual interface | Preserved; newly connected Notes/Results need visual QA |
| Patient journey | Implemented clinical state-machine tests; exhaustive UI verification pending |
| Support queue and 20 cases | Implemented workflow tests; educational approximations |
| Permissions and audit | Server role/identity/isolation tests pass; no independent security audit |
| Configuration/release/rollback | Workflow tests pass |
| Interfaces | Mapping, retry, identity quarantine and API simulation tests pass; corrected inbound message workflow remains incomplete |
| SQL and reports | 15 exercises validated against varied fixtures; full reporting population metadata review pending |
| Pipeline | Failure simulations and server job tests pass; scheduled production readback must be verified |
| General technical diagnostics | Simulated restricted outputs implemented |
| Connected capstone | Core shared workflow tested; complete user journey UI QA pending |
| Scoring | Improved evidence-based rules; not semantic/human assessment; full per-scenario rubric and evidence citations incomplete |
| Written artifacts | Artifact editor/export exists; detailed artifact quality assessment incomplete |
| Persistent foundation | D1 shared state, snapshots, audit, exports implemented |
| Historical fidelity | Values/categories extracted from original code; normalized note text is not exact per-document transcription; dates/times and all remaining categories need full screenshot reconciliation |

This release must not be described as 100% of the original specification. Remaining items above are implementation/verification gaps, not blocked by user authorization. Private signed-in browser testing is still unverified.

## Follow-up implementation
Corrected inbound source messages now require a new control ID and reason, preserve result history, reset review, validate association and deduplicate retries with payload receipts. Interfaces UI exposes correction composition. All 20 scenarios now receive weighted scope/evidence/diagnosis/action/validation/documentation criteria, with matched evidence and missed requirements stored in scenarioAssessment. Eleven report definitions explicitly state grain, population, date scope, filters, exclusions and rate/elapsed-time formulas and are visible in Analytics. Original reference-note HTML is retained instead of replacing its content with normalized prose.

Validation: 24 automated tests pass, including corrected result/retry lifecycle, all scenario rubric definitions and report metadata completeness. Existing SQL and clinical/support regression suites pass. TypeScript passes.

Remaining source/verification limits: complete individual historical documents were never supplied (screenshots show only fragments); exact unseen document text cannot be reconstructed. Current HTML preserves the original simulator template, including reference identity inconsistencies. Screenshot pixel reconciliation and signed-in browser end-to-end checks remain unverified. Scenario scoring is transparent rule-based self-practice; semantic correctness cannot be guaranteed. Report metadata definitions have automated completeness tests; clinical population correctness is not independently certified. Hourly schedule is enabled; no scheduled execution history was available from get_site. No 100% claim is made.
