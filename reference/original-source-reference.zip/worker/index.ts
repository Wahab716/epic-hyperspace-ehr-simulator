import {processScheduledWorkspaces,processWorkspaceJobs} from '../lib/training/background.mjs';
import handler from "vinext/server/fetch-handler";
import { runWithConnectorBinding } from "../lib/connector-context";
import type { ConnectorBinding } from "../lib/connector-contract.mjs";

const worker = {
  scheduled(_event: ScheduledController, env: Cloudflare.Env, ctx: ExecutionContext) { ctx.waitUntil(processScheduledWorkspaces(env.DB)); },
  fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext<{ CONNECTORS?: ConnectorBinding }>) {
    let binding = ctx.props?.CONNECTORS;
    // Local preview emulates the same request-scoped capability. This branch and
    // the auxiliary service binding are absent from production builds.
    if (import.meta.env.DEV && !binding && env.CONNECTORS) {
      const preview = env.CONNECTORS;
      const expiresAt = Date.now() + 60_000;
      binding = {
        async getContext() {
          if (Date.now() >= expiresAt) return { status: "request_context_expired" };
          return preview.getContext?.() ?? { status: "binding_unavailable" };
        },
        async invoke(connectorId, actionName, args) {
          if (Date.now() >= expiresAt) {
            return { status: "request_context_expired", message: "This request has expired. Please try again." };
          }
          return preview.invoke(connectorId, actionName, args);
        },
      };
    }
    const response = runWithConnectorBinding(binding, () => handler.fetch(request, env, ctx));
    const owner = request.headers.get('oai-authenticated-user-id') || (import.meta.env.DEV ? 'local-preview' : null);
    if (owner && env.DB && request.method === 'POST' && new URL(request.url).pathname === '/api/workspace') {
      ctx.waitUntil(Promise.resolve(response).then(async (r) => { if(r.ok) await processWorkspaceJobs(env.DB!, owner); }));
    }
    return response;
  },
};

export default worker;
